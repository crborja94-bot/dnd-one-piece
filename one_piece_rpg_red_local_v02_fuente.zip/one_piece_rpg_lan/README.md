# One Piece RPG — proyectos Android LAN (fase 0.2)

Dos proyectos Android independientes: `MasterApp/` y `PlayerApp/`.

## Añadido en esta versión
- Anfitrión HTTP local en el móvil del máster, puerto 8765.
- Código de emparejamiento aleatorio de seis cifras.
- Estado inicial de campaña guardado en preferencias privadas del anfitrión.
- Endpoint de lectura `GET /state`, protegido por el código de emparejamiento.
- Pantalla de jugador que conecta y muestra el estado recibido.

## Estado real
**Esto sigue siendo código fuente de desarrollo, no APK finales ni un juego listo para jugar.** No se ha compilado ni probado en teléfonos reales. No implementa todavía creación de campañas y personajes, permisos por usuario, edición de estado desde los jugadores, combates, tiendas, compras atómicas, fondo común, sincronización automática de eventos ni copias de seguridad.

La conexión usa HTTP sin cifrar en la red local. El código de seis cifras es una barrera provisional, no seguridad de producción. Úsalo solo en una red de confianza y no expongas el puerto a Internet.

## Probar cuando se compile
1. Abrir `MasterApp/` en Android Studio y compilar/instalar.
2. Abrir `PlayerApp/` en Android Studio y compilar/instalar.
3. Conectar ambos teléfonos a la misma Wi-Fi.
4. En Máster, copiar IP y código.
5. En Jugadores, introducirlos y tocar «Conectar y cargar estado».

Las redes Wi-Fi de invitados pueden bloquear conexiones entre dispositivos. El anfitrión debe permanecer abierto.

## Siguiente fase
Construir los modelos y pantallas reales de campañas, fichas, inventarios y combate; después validar todas las operaciones en el anfitrión, implementar sincronización y exportación de copias, y probar en Android real.
