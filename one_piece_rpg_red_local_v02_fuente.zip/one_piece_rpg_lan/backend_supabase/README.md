# Backend compartido — esquema inicial

Este SQL es una base de datos inicial para campañas, miembros, personajes, tiendas, inventarios y compras. No constituye un backend de producción terminado.

Pendiente antes de uso real:
1. Implementar y probar políticas RLS por campaña y rol.
2. Crear funciones RPC transaccionales para compras, berries, existencias y fondo común.
3. Validar invitaciones, aprobaciones de personajes, combate y permisos del máster en el servidor.
4. Añadir tablas y eventos de tiempo real para combate, viajes, misiones, Bestiario, historial de fondo común, recompensas y demás módulos acordados.
5. Conectar ambas apps a Supabase con URL y clave pública del proyecto; nunca incrustar una clave `service_role` en una APK.
