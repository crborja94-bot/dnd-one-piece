-- Esquema inicial para Supabase/PostgreSQL.
-- No desplegar en producción sin revisar y probar todas las políticas RLS.
create extension if not exists pgcrypto;

create type public.campaign_member_role as enum ('master','player');
create type public.character_status as enum ('draft','pending','approved','changes_requested');
create type public.shop_status as enum ('hidden','open','closed');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default ''
);

create table public.campaigns (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  invite_code text not null unique,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.campaign_members (
  campaign_id uuid not null references public.campaigns(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.campaign_member_role not null,
  joined_at timestamptz not null default now(),
  primary key(campaign_id,user_id)
);

create table public.characters (
  id uuid primary key default gen_random_uuid(),
  campaign_id uuid not null references public.campaigns(id) on delete cascade,
  owner_id uuid not null references auth.users(id),
  name text not null,
  status public.character_status not null default 'draft',
  sheet jsonb not null default '{}'::jsonb,
  hp_current integer not null default 1,
  hp_max integer not null default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (hp_max >= 0)
);

create table public.shops (
  id uuid primary key default gen_random_uuid(),
  campaign_id uuid not null references public.campaigns(id) on delete cascade,
  name text not null,
  description text not null default '',
  status public.shop_status not null default 'hidden',
  created_by uuid not null references auth.users(id),
  updated_at timestamptz not null default now()
);

create table public.shop_products (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.shops(id) on delete cascade,
  name text not null,
  description text not null default '',
  category text not null default 'general',
  price_berries bigint not null check (price_berries >= 0),
  stock integer,
  active boolean not null default true,
  inventory_payload jsonb not null default '{}'::jsonb,
  check (stock is null or stock >= 0)
);

create table public.character_wallets (
  character_id uuid primary key references public.characters(id) on delete cascade,
  berries bigint not null default 0 check (berries >= 0)
);

create table public.character_inventory (
  id uuid primary key default gen_random_uuid(),
  character_id uuid not null references public.characters(id) on delete cascade,
  item_key text not null,
  item_name text not null,
  quantity integer not null check (quantity > 0),
  details jsonb not null default '{}'::jsonb,
  unique(character_id,item_key)
);

create table public.shop_transactions (
  id uuid primary key default gen_random_uuid(),
  campaign_id uuid not null references public.campaigns(id) on delete cascade,
  shop_id uuid not null references public.shops(id),
  product_id uuid not null references public.shop_products(id),
  character_id uuid not null references public.characters(id),
  buyer_id uuid not null references auth.users(id),
  quantity integer not null check (quantity > 0),
  unit_price_berries bigint not null check (unit_price_berries >= 0),
  total_berries bigint not null check (total_berries >= 0),
  created_at timestamptz not null default now()
);

-- Las políticas de producción deben implementarse y probarse antes de conectar clientes.
-- No habilitar RLS sin definir políticas completas: podría bloquear el uso o dejar datos expuestos.
alter table public.profiles enable row level security;
alter table public.campaigns enable row level security;
alter table public.campaign_members enable row level security;
alter table public.characters enable row level security;
alter table public.shops enable row level security;
alter table public.shop_products enable row level security;
alter table public.character_wallets enable row level security;
alter table public.character_inventory enable row level security;
alter table public.shop_transactions enable row level security;
