# One Piece RPG Máster

Proyecto fuente Android inicial (com.onepiecerpg.master), basado en el prototipo web incluido en `app/src/main/assets/index.html`.

## Compilar
Requiere Android Studio y Android SDK 35. Abre esta carpeta como proyecto Gradle y ejecuta **Build > Build APK(s)**.

## Estado y limitaciones
- Es un contenedor Android del prototipo, no una aplicación final.
- Los datos del prototipo se guardan localmente en el dispositivo.
- No hay autenticación real, base de datos compartida, comunicación en tiempo real ni controles de permisos del servidor.
- El selector de rol y las pantallas del prototipo no sustituyen la separación segura entre la app de máster y la de jugadores.
- No distribuir para una campaña real hasta implementar y probar el backend y sus políticas de seguridad.
