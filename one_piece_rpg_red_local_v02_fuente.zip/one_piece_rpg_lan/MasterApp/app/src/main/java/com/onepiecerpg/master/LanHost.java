package com.onepiecerpg.master;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.text.format.Formatter;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;

public final class LanHost {
    public static final int PORT = 8765;
    private final Context context;
    private final SharedPreferences prefs;
    private final String pin;
    private volatile boolean running;
    private ServerSocket server;

    public LanHost(Context context) {
        this.context = context.getApplicationContext();
        prefs = this.context.getSharedPreferences("opr_state", Context.MODE_PRIVATE);
        pin = String.format("%06d", new SecureRandom().nextInt(1_000_000));
        if (!prefs.contains("state")) {
            try {
                JSONObject state = new JSONObject();
                state.put("schemaVersion", 1);
                state.put("campaignName", "Nueva aventura");
                state.put("players", new JSONArray());
                state.put("characters", new JSONArray());
                state.put("combat", new JSONObject().put("active", false).put("round", 0));
                state.put("shops", new JSONArray());
                state.put("commonFund", new JSONObject().put("berries", 0).put("items", new JSONArray()));
                state.put("updatedAt", System.currentTimeMillis());
                prefs.edit().putString("state", state.toString()).apply();
            } catch (Exception ignored) {}
        }
    }

    public String getPin() { return pin; }
    public String getLocalIp() {
        try {
            WifiManager wm = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
            if (wm != null) return Formatter.formatIpAddress(wm.getConnectionInfo().getIpAddress());
        } catch (Exception ignored) {}
        return "No disponible: conecta el móvil a la Wi-Fi";
    }

    public synchronized void start() {
        if (running) return;
        running = true;
        Thread t = new Thread(() -> {
            try (ServerSocket ss = new ServerSocket(PORT)) {
                server = ss;
                while (running) {
                    Socket s = ss.accept();
                    s.setSoTimeout(4000);
                    new Thread(() -> handle(s), "OPR-client").start();
                }
            } catch (IOException e) { running = false; }
        }, "OPR-host");
        t.setDaemon(true);
        t.start();
    }

    private void handle(Socket socket) {
        try (Socket s = socket;
             BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
             OutputStream out = s.getOutputStream()) {
            String first = in.readLine();
            if (first == null) return;
            String[] p = first.split(" ");
            String path = p.length > 1 ? p[1] : "/";
            String line, suppliedPin = "";
            while ((line = in.readLine()) != null && !line.isEmpty()) {
                int ix = line.indexOf(':');
                if (ix > 0 && line.substring(0, ix).trim().equalsIgnoreCase("X-OPR-PIN"))
                    suppliedPin = line.substring(ix + 1).trim();
            }
            int status = 200;
            String body;
            if ("/health".equals(path)) {
                body = "{\"ok\":true,\"service\":\"one-piece-rpg-lan\"}";
            } else if (!pin.equals(suppliedPin)) {
                status = 403;
                body = "{\"ok\":false,\"error\":\"Código incorrecto\"}";
            } else if ("/state".equals(path)) {
                body = prefs.getString("state", "{}");
            } else {
                status = 404;
                body = "{\"ok\":false,\"error\":\"Ruta no encontrada\"}";
            }
            byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
            String reason = status == 200 ? "OK" : status == 403 ? "Forbidden" : "Not Found";
            String headers = "HTTP/1.1 " + status + " " + reason + "\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: " + bytes.length + "\r\nConnection: close\r\n\r\n";
            out.write(headers.getBytes(StandardCharsets.UTF_8));
            out.write(bytes);
            out.flush();
        } catch (Exception ignored) {}
    }

    public synchronized void stop() {
        running = false;
        try { if (server != null) server.close(); } catch (Exception ignored) {}
    }
}
