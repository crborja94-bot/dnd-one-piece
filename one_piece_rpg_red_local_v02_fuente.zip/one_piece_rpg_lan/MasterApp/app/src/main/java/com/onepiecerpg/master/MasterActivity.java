package com.onepiecerpg.master;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MasterActivity extends Activity {
    private LanHost host;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        host = new LanHost(this);
        host.start();
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 28, 28, 28);
        TextView title = new TextView(this);
        title.setText("ONE PIECE RPG\nMÁSTER");
        title.setTextSize(26);
        title.setTypeface(null, Typeface.BOLD);
        page.addView(title);
        TextView info = new TextView(this);
        info.setText("\nAnfitrión de red local\n\nIP Wi-Fi: " + host.getLocalIp()
            + "\nPuerto: " + LanHost.PORT + "\nCódigo de emparejamiento: " + host.getPin()
            + "\n\nMantén esta app abierta durante la partida. Los jugadores deben conectarse a la misma Wi-Fi."
            + "\n\nEstado de desarrollo:\n• API local básica\n• Estado de partida guardado en este móvil\n• Las fichas, combates, tiendas y operaciones aún deben implementarse.");
        info.setTextSize(16);
        page.addView(info);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(page);
        setContentView(scroll);
    }
    @Override protected void onDestroy() {
        if (host != null) host.stop();
        super.onDestroy();
    }
}
