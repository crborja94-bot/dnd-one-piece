package com.onepiecerpg.players;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class PlayersActivity extends Activity {
    private EditText ipInput, pinInput;
    private TextView status, stateView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 28, 28, 28);
        TextView title = new TextView(this);
        title.setText("ONE PIECE RPG\nJUGADORES");
        title.setTextSize(26);
        title.setTypeface(null, Typeface.BOLD);
        page.addView(title);
        TextView help = new TextView(this);
        help.setText("\nIntroduce la IP y el código que muestra la app del máster. Ambos móviles deben estar en la misma Wi-Fi.");
        help.setTextSize(16);
        page.addView(help);
        ipInput = new EditText(this);
        ipInput.setSingleLine(true);
        ipInput.setHint("IP del máster, por ejemplo 192.168.1.20");
        page.addView(ipInput);
        pinInput = new EditText(this);
        pinInput.setSingleLine(true);
        pinInput.setHint("Código de emparejamiento de 6 cifras");
        pinInput.setInputType(2);
        page.addView(pinInput);
        Button connect = new Button(this);
        connect.setText("Conectar y cargar estado");
        page.addView(connect);
        status = new TextView(this);
        status.setText("\nSin conexión");
        status.setTextSize(15);
        page.addView(status);
        stateView = new TextView(this);
        stateView.setText("\nEl estado compartido aparecerá aquí.");
        stateView.setTextSize(14);
        page.addView(stateView);
        connect.setOnClickListener(v -> loadState());
        ScrollView scroll = new ScrollView(this);
        scroll.addView(page);
        setContentView(scroll);
    }
    private void loadState() {
        String ip = ipInput.getText().toString().trim();
        String pin = pinInput.getText().toString().trim();
        if (ip.isEmpty() || pin.length() != 6) {
            status.setText("Introduce la IP y el código de seis cifras.");
            return;
        }
        status.setText("Conectando…");
        new Thread(() -> {
            String message;
            String stateText = "";
            try {
                HttpURLConnection c = (HttpURLConnection)new URL("http://" + ip + ":8765/state").openConnection();
                c.setConnectTimeout(4000);
                c.setReadTimeout(4000);
                c.setRequestProperty("X-OPR-PIN", pin);
                int code = c.getResponseCode();
                BufferedReader r = new BufferedReader(new InputStreamReader(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream()));
                StringBuilder b = new StringBuilder();
                String line;
                while ((line = r.readLine()) != null) b.append(line);
                r.close();
                c.disconnect();
                if (code == 200) {
                    JSONObject data = new JSONObject(b.toString());
                    int chars = data.optJSONArray("characters") == null ? 0 : data.optJSONArray("characters").length();
                    int players = data.optJSONArray("players") == null ? 0 : data.optJSONArray("players").length();
                    JSONObject combat = data.optJSONObject("combat");
                    stateText = "Campaña: " + data.optString("campaignName", "Sin nombre")
                        + "\nJugadores: " + players + "\nPersonajes: " + chars
                        + "\nCombate activo: " + (combat != null && combat.optBoolean("active", false) ? "Sí" : "No")
                        + "\n\nJSON recibido:\n" + data.toString(2);
                    message = "Conexión correcta. Estado recibido del anfitrión.";
                } else message = "Acceso rechazado: revisa el código.";
            } catch (Exception e) {
                message = "No se pudo conectar. Comprueba IP, código, Wi-Fi y que la app del máster esté abierta.";
            }
            final String m = message, s = stateText;
            runOnUiThread(() -> { status.setText(m); if (!s.isEmpty()) stateView.setText(s); });
        }).start();
    }
}
